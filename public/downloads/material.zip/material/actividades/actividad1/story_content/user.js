function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6V2h8ALqTMM":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

